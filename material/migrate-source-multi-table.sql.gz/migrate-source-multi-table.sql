-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `migrate-source-multi-table` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `migrate-source-multi-table`;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `city` varchar(255) NOT NULL,
  `site_url` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `author` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `title`, `body`, `city`, `site_url`, `state`, `site_name`, `keywords`, `created_date`, `author`) VALUES
(1,	'Hello world',	'Hello world body',	'Delhi',	'https://google.com',	'Delhi',	'Google',	'home,example1',	'2016-11-05 08:30:53',	3),
(2,	'Amazing page',	'This is body of amazing page.',	'Ahmedabad',	'https://facebook.com',	'Gujarat',	'Facebook',	'social, page',	'2016-11-05 08:02:26',	4);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`uid`, `username`, `password`, `email`, `created`) VALUES
(3,	'user1',	'24c9e15e52afc47c225b757e7bee1f9d',	'user1@gmail.com',	'2016-11-08 14:49:13'),
(4,	'user2',	'7e58d63b60197ceb55a1c487989a3720',	'user2@gmail.com',	'2016-11-07 14:49:21');

-- 2016-11-09 05:09:30
